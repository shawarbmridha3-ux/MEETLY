# MEETLY — Consolidated App Prototype

This single project contains the current MEETLY UI prototype:
- Home
- Live
- Random Match
- Profile
- VIP card
- Coins
- Top Hosts
- Basic Settings
- Light Mode / Dark Mode
- Bottom navigation

## Run
Install Flutter, then from this folder:

    flutter pub get
    flutter run

## Production work still required
This package is a UI/prototype starter. A production app needs:
authentication, secure backend/database, real-time chat, compliant video infrastructure,
age gating, report/block and moderation tools, privacy/security controls, notifications,
server-side coin/wallet validation, payments, analytics, testing, and store configuration.

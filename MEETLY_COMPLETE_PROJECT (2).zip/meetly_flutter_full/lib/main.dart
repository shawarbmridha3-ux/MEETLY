import 'package:flutter/material.dart';

void main() => runApp(const MeetlyApp());

class MeetlyApp extends StatefulWidget {
  const MeetlyApp({super.key});
  @override State<MeetlyApp> createState() => _MeetlyAppState();
}

class _MeetlyAppState extends State<MeetlyApp> {
  ThemeMode mode = ThemeMode.light;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MEETLY',
      themeMode: mode,
      theme: ThemeData(
        brightness: Brightness.light,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF6F9FF),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF246BFE)),
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF050505),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFB832FF),
          brightness: Brightness.dark,
        ),
      ),
      home: MainShell(
        dark: mode == ThemeMode.dark,
        onTheme: () => setState(() =>
          mode = mode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  final bool dark;
  final VoidCallback onTheme;
  const MainShell({super.key, required this.dark, required this.onTheme});
  @override State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  final pages = const [
    HomePage(),
    LivePage(),
    MatchPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.videocam_outlined), selectedIcon: Icon(Icons.videocam), label: 'Live'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Match'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
        children: [
          Row(children: [
            Text('MEETLY', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900,
              color: dark ? Colors.amber : const Color(0xFF1557D6))),
            const Spacer(),
            _coinChip(),
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
            IconButton(onPressed: () {
              final state = context.findAncestorStateOfType<_MeetlyAppState>();
              state?.setState(() => state.mode =
                state.mode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light);
            }, icon: Icon(dark ? Icons.light_mode : Icons.dark_mode)),
          ]),
          const SizedBox(height: 10),
          _vipCard(dark),
          const SizedBox(height: 18),
          const _QuickActions(),
          const SizedBox(height: 22),
          _title('Popular Live'),
          const SizedBox(height: 10),
          SizedBox(height: 190, child: ListView.separated(
            scrollDirection: Axis.horizontal, itemCount: 6,
            separatorBuilder: (_,__) => const SizedBox(width: 10),
            itemBuilder: (_,i) => _LiveCard(name: ['Ariya','Jessica','Meera','Riya','Hanna','Bella'][i], i:i),
          )),
          const SizedBox(height: 22),
          _title('Top Hosts'),
          const SizedBox(height: 10),
          SizedBox(height: 110, child: ListView.separated(
            scrollDirection: Axis.horizontal, itemCount: 5,
            separatorBuilder: (_,__) => const SizedBox(width: 18),
            itemBuilder: (_,i) => _Host(name: ['Sara','Nisha','Angel','Tanya','Riya'][i], i:i),
          )),
        ],
      ),
    );
  }

  Widget _coinChip() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
    decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(20)),
    child: const Row(children: [
      Icon(Icons.monetization_on, color: Colors.amber, size: 19),
      SizedBox(width: 5), Text('12,560', style: TextStyle(fontWeight: FontWeight.bold)),
      SizedBox(width: 5), Icon(Icons.add_circle_outline, size: 17)
    ]),
  );

  Widget _vipCard(bool dark) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      gradient: LinearGradient(colors: dark
        ? [const Color(0xFF180B27), const Color(0xFF35105B)]
        : [const Color(0xFFEAF2FF), const Color(0xFFD9E7FF)]),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: dark ? Colors.purpleAccent : const Color(0xFF9BBEFF)),
    ),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('VIP MEMBERSHIP', style: TextStyle(fontWeight: FontWeight.w900,
          color: dark ? Colors.amber : const Color(0xFF1759D6))),
        const SizedBox(height: 7),
        const Text('Unlock premium features and enjoy more fun!'),
        const SizedBox(height: 10),
        FilledButton(onPressed: () {}, child: const Text('UPGRADE')),
      ])),
      const Icon(Icons.workspace_premium, color: Colors.amber, size: 70)
    ]),
  );

  Widget _title(String s) => Row(children: [
    Text(s, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
    const Spacer(), TextButton(onPressed: () {}, child: const Text('See All ›'))
  ]);
}

class _QuickActions extends StatelessWidget {
  const _QuickActions();
  @override Widget build(BuildContext context) {
    final a = [(Icons.videocam,'Live'),(Icons.shuffle,'Random Match'),
      (Icons.chat_bubble,'Chat'),(Icons.emoji_events,'Ranking'),(Icons.workspace_premium,'VIP')];
    return Row(children: a.map((x) => Expanded(child: Column(children: [
      CircleAvatar(radius: 27, backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
        child: Icon(x.$1, color: Theme.of(context).colorScheme.primary)),
      const SizedBox(height: 6), Text(x.$2, textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 11))
    ]))).toList());
  }
}

class _LiveCard extends StatelessWidget {
  final String name; final int i;
  const _LiveCard({required this.name, required this.i});
  @override Widget build(BuildContext context) {
    final cs = [[Colors.indigo,Colors.pink],[Colors.orange,Colors.red],
      [Colors.teal,Colors.blue],[Colors.purple,Colors.indigo]][i%4];
    return Container(width: 135, decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      gradient: LinearGradient(begin: Alignment.topCenter,end: Alignment.bottomCenter,colors: cs)),
      child: Stack(children: [
        const Center(child: Icon(Icons.person, color: Colors.white70, size: 90)),
        Positioned(left:8,top:8,child: Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:4),
          decoration:BoxDecoration(color:Colors.pink,borderRadius:BorderRadius.circular(8)),
          child:const Text('LIVE',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold,fontSize:10)))),
        Positioned(left:9,bottom:10,child:Column(crossAxisAlignment:CrossAxisAlignment.start,
          children:[Text(name,style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold,fontSize:16)),
          const Text('● 1.2K viewers',style:TextStyle(color:Colors.white70,fontSize:11))]))
      ]));
  }
}

class _Host extends StatelessWidget {
  final String name; final int i;
  const _Host({required this.name, required this.i});
  @override Widget build(BuildContext context) => Column(children:[
    CircleAvatar(radius:34,backgroundColor:[Colors.purple,Colors.pink,Colors.amber,Colors.red,Colors.cyan][i],
      child:const CircleAvatar(radius:30,backgroundColor:Colors.grey,child:Icon(Icons.person,color:Colors.white,size:34))),
    const SizedBox(height:5), Text(name,style:const TextStyle(fontWeight:FontWeight.w700)),
    const Text('★ 1.8K',style:TextStyle(fontSize:11,color:Colors.amber))
  ]);
}

class LivePage extends StatelessWidget {
  const LivePage({super.key});
  @override Widget build(BuildContext context) => _Page(title:'Live', child: Column(children:[
    const _Tabs(items:['Popular','Nearby','New','Following']),
    const SizedBox(height:12),
    Expanded(child: GridView.builder(
      padding: const EdgeInsets.all(2), itemCount: 8,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount:2, crossAxisSpacing:10, mainAxisSpacing:10, childAspectRatio:.72),
      itemBuilder:(_,i)=>_LiveCard(name:['Bella','Olivia','Riya','Hanna','Ariya','Meera','Sara','Angel'][i],i:i))
    )
  ]));
}

class MatchPage extends StatefulWidget {
  const MatchPage({super.key});
  @override State<MatchPage> createState()=>_MatchPageState();
}
class _MatchPageState extends State<MatchPage> {
  bool searching=false;
  @override Widget build(BuildContext context) => _Page(title:'Random Match',
    child: Column(children:[
      const SizedBox(height:30),
      const Icon(Icons.public,size:110,color:Color(0xFF246BFE)),
      const SizedBox(height:18),
      const Text('Find someone awesome for you...',style:TextStyle(fontSize:18,fontWeight:FontWeight.w600)),
      const Spacer(),
      const _FilterRow(),
      const SizedBox(height:18),
      SizedBox(width:double.infinity,height:54,child:FilledButton(
        onPressed:()=>setState(()=>searching=!searching),
        child:Text(searching?'STOP MATCHING':'START MATCHING'))),
      const SizedBox(height:20),
      const Text('You can update your preferences anytime from settings.',
        style:TextStyle(fontSize:12)),
      const SizedBox(height:30)
    ]));
}

class _FilterRow extends StatelessWidget {
  const _FilterRow();
  @override Widget build(BuildContext context)=>Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,
    children:['Both','18+','All Countries'].map((s)=>FilterChip(label:Text(s),onSelected:(_){},selected:false)).toList());
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override Widget build(BuildContext context) => _Page(title:'My Profile',
    actions:[IconButton(onPressed:()=>_settings(context),icon:const Icon(Icons.settings))],
    child:ListView(children:[
      const SizedBox(height:10),
      const CircleAvatar(radius:55,backgroundColor:Colors.amber,
        child:CircleAvatar(radius:50,backgroundColor:Colors.grey,child:Icon(Icons.person,size:60,color:Colors.white))),
      const SizedBox(height:10),
      const Center(child:Text('Alex Roy',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900))),
      const Center(child:Text('ID: 4587 9210')),
      const SizedBox(height:18),
      Row(children:[
        _stat('Coins','12,560'),_stat('Diamonds','2,350'),_stat('Level','25')]),
      const SizedBox(height:20),
      GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:4,
        children:['Moments','Visitors','Liked Me','Friends','Wallet','Store','Level','VIP'].map((s)=>Column(children:[
          CircleAvatar(child:Icon(Icons.apps)),const SizedBox(height:5),Text(s,style:const TextStyle(fontSize:11))
        ])).toList()),
    ]));
  Widget _stat(String a,String b)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(12),
    child:Column(children:[Text(a),Text(b,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:17))]))));
  void _settings(BuildContext c)=>showModalBottomSheet(context:c,builder:(_)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[
    ListTile(leading:const Icon(Icons.person),title:const Text('Account Information'),onTap:()=>Navigator.pop(c)),
    ListTile(leading:const Icon(Icons.shield),title:const Text('Privacy & Safety'),onTap:()=>Navigator.pop(c)),
    ListTile(leading:const Icon(Icons.notifications),title:const Text('Notifications'),onTap:()=>Navigator.pop(c)),
    ListTile(leading:const Icon(Icons.block),title:const Text('Blocked Users'),onTap:()=>Navigator.pop(c)),
    ListTile(leading:const Icon(Icons.help),title:const Text('Help & Support'),onTap:()=>Navigator.pop(c)),
  ])));
}

class _Page extends StatelessWidget {
  final String title; final Widget child; final List<Widget>? actions;
  const _Page({required this.title,required this.child,this.actions});
  @override Widget build(BuildContext context)=>SafeArea(child:Padding(
    padding:const EdgeInsets.fromLTRB(16,10,16,10),
    child:Column(children:[
      Row(children:[IconButton(onPressed:()=>Navigator.maybePop(context),icon:const Icon(Icons.arrow_back)),
        Text(title,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w800)),const Spacer(),...(actions??[]) ]),
      const SizedBox(height:6),Expanded(child:child)
    ])));
}

class _Tabs extends StatelessWidget {
  final List<String> items; const _Tabs({required this.items});
  @override Widget build(BuildContext context)=>Row(mainAxisAlignment:MainAxisAlignment.spaceAround,
    children:items.map((x)=>Text(x,style:TextStyle(fontWeight:x=='Popular'?FontWeight.w900:FontWeight.w500,
      color:x=='Popular'?Theme.of(context).colorScheme.primary:null))).toList());
}

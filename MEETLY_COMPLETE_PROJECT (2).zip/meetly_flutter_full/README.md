# MEETLY Flutter Starter v2

UI-first starter matching the requested MEETLY concept.

Included:
- Home
- Light/Dark mode
- Live page
- Random Match page
- Profile page
- VIP card
- Coins
- Top hosts
- Navigation
- Basic settings sheet

Run:
flutter pub get
flutter run

Important:
This is a prototype UI, not a production live-video service. Before launch,
implement secure authentication, backend/database, real-time chat, a compliant
video infrastructure, age gating, reporting/blocking, moderation, privacy,
payments and server-side wallet/coin validation.
